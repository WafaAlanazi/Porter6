

import os
import torch
import subprocess
import numpy as np  # Import NumPy for saving arrays
from Bio import SeqIO  # Use Biopython to read FASTA files

try:
    import esm
except ImportError:
    # If esm is not found, install it
    subprocess.check_call(["pip", "install", "fair-esm"])
    import esm

torch.set_grad_enabled(False)
# Automatically use the dataset directory relative to the script location
dataset_dir = os.path.join(os.path.dirname(__file__), 'data', 'dataset')
fasta_file_path = os.path.join(dataset_dir, 'set3.fasta')
# Load ESM-2 model
model, alphabet = esm.pretrained.esm2_t33_650M_UR50D()
batch_converter = alphabet.get_batch_converter()
model.eval()  # disables dropout for deterministic results

# Function to read sequences from a FASTA file
def read_fasta(file_path):
    sequences = []
    for record in SeqIO.parse(file_path, "fasta"):
        sequences.append({
            'id': record.id,
            'sequence': str(record.seq)
        })
    return sequences

# Path to the FASTA file
#fasta_file_path = '/home/people/20203023/scratch/porter6/data/dataset/set3.fasta'

# Read sequences from the FASTA file
list_entity = read_fasta(fasta_file_path)

# Path to save the embeddings
path_embedded_esm2 = "/home/people/20203023/scratch/porter6/data/features/esm2"
if not os.path.exists(path_embedded_esm2):
    os.mkdir(path_embedded_esm2)

# Iterate through each sequence in the FASTA file
for entity in list_entity:
    print(entity['id'])
    data = [(entity['id'], entity['sequence'])]
    batch_labels, batch_strs, batch_tokens = batch_converter(data)

    # Extract per-residue representations (on CPU)
    with torch.no_grad():
        results = model(batch_tokens, repr_layers=[33], return_contacts=False)
    token_representations = results["representations"][33]

    embedded_seq = token_representations[0, 1 : - 1].numpy()

    # Save the embedding using numpy.save
    np.save(os.path.join(path_embedded_esm2, f"{entity['id']}.npy"), embedded_seq)

print('Done!!!!')

