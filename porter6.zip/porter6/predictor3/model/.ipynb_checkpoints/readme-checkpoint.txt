lstm_np.py
    - using packed_padding
    - with train_rnn.py

cnn_np.py

rnn1.py & rnn2.py (with dropout)
    - not using packed_padding
    - with train.py

cnn.py
    - padding
    - with train.py