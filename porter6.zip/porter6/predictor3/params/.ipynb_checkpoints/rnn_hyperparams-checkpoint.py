# unidirection 1
bidirectional = True
# num_layers=3
# hidden_size=[50, 30, 20]
num_layers=2
hidden_size=24

'''
# unidirection 1
bidirectional = True
num_layers=2
hidden_size=50
'''
'''
# unidirection 3
bidirectional = False
num_layers=4
hidden_size=24
'''
'''
# bidirection
bidirectional = True
num_layers=2
hidden_size=48
'''
