#!/bin/bash

# Step 1: Run Python scripts in the porter6 directory
cd /porter6

# Step 1: Convert FASTA to JSON
echo "Running fasta2json.py..."
python fasta2json.py
if [ $? -ne 0 ]; then
    echo "Error running fasta2json.py. Exiting."
    exit 1
fi

# Step 2: Generate embeddings with ESM
echo "Running emb_esm3_fasta.py..."
python emb_esm3_fasta.py
if [ $? -ne 0 ]; then
    echo "Error running emb_esm3_fasta.py. Exiting."
    exit 1
fi

# Step 3: Run Python scripts in predictor3 directory
cd /porter6/predictor3

echo "Running new_test_ensemble.py in predictor3..."
python new_test_ensemble.py
if [ $? -ne 0 ]; then
    echo "Error running new_test_ensemble.py. Exiting."
    exit 1
fi

echo "Running json2csv3.py in predictor3..."
python json2csv3.py
if [ $? -ne 0 ]; then
    echo "Error running json2csv3.py. Exiting."
    exit 1
fi

# Step 4: Run Python scripts in predictor8 directory
cd /porter6/predictor8

echo "Running new_test_ensemble.py in predictor8..."
python new_test_ensemble.py
if [ $? -ne 0 ]; then
    echo "Error running new_test_ensemble.py. Exiting."
    exit 1
fi

echo "Running json2csv8.py in predictor8..."
python json2csv8.py
if [ $? -ne 0 ]; then
    echo "Error running json2csv8.py. Exiting."
    exit 1
fi

echo "All steps completed successfully!"
